ActivityCompat.requestPermissions(
this,
new String[]{Manifest.permission.RECORD_AUDIO},
1
);